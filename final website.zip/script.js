/******************************
  GLOBAL STORAGE STRUCTURE
*******************************/
if (!localStorage.getItem("kasutiChampionship")) {
  localStorage.setItem(
    "kasutiChampionship",
    JSON.stringify({
      football: { fixtures: [], results: [], standings: {} },
      netball: { fixtures: [], results: [], standings: {} },
      applications: []
    })
  );
}

function getData() {
  return JSON.parse(localStorage.getItem("kasutiChampionship"));
}

function saveData(data) {
  localStorage.setItem("kasutiChampionship", JSON.stringify(data));
}

/******************************
  FIXTURES & RESULTS
*******************************/
function addResult(type, matchNo, homeScore, awayScore) {
  let data = getData();
  const fixture = data[type].fixtures.find(f => f.matchNo === matchNo);
  if (!fixture) {
    alert("❌ Match not found in fixtures.");
    return;
  }

  const result = {
    matchNo,
    date: fixture.date,
    homeTeam: fixture.homeTeam,
    awayTeam: fixture.awayTeam,
    venue: fixture.venue,
    score: `${homeScore} - ${awayScore}`
  };

  // Save result
  data[type].results = data[type].results.filter(r => r.matchNo !== matchNo);
  data[type].results.push(result);

  // Update standings
  updateStandings(data, type, fixture.homeTeam, fixture.awayTeam, homeScore, awayScore);

  saveData(data);
  alert("✅ Result saved successfully!");
  renderResults(type);
  renderStandings(type);
}

function updateStandings(data, type, home, away, homeScore, awayScore) {
  if (!data[type].standings[home]) {
    data[type].standings[home] = { team: home, played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, gd: 0, points: 0 };
  }
  if (!data[type].standings[away]) {
    data[type].standings[away] = { team: away, played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, gd: 0, points: 0 };
  }

  let homeTeam = data[type].standings[home];
  let awayTeam = data[type].standings[away];

  homeTeam.played++;
  awayTeam.played++;
  homeTeam.gf += homeScore;
  homeTeam.ga += awayScore;
  awayTeam.gf += awayScore;
  awayTeam.ga += homeScore;
  homeTeam.gd = homeTeam.gf - homeTeam.ga;
  awayTeam.gd = awayTeam.gf - awayTeam.ga;

  if (homeScore > awayScore) {
    homeTeam.won++; homeTeam.points += 3;
    awayTeam.lost++;
  } else if (homeScore < awayScore) {
    awayTeam.won++; awayTeam.points += 3;
    homeTeam.lost++;
  } else {
    homeTeam.drawn++; awayTeam.drawn++;
    homeTeam.points++; awayTeam.points++;
  }
}

/******************************
  RENDER FUNCTIONS
*******************************/
function renderResults(type) {
  const data = getData();
  const table = document.getElementById(`${type}-results-table`);
  if (!table) return;
  table.innerHTML = "";
  data[type].results.forEach(r => {
    table.innerHTML += `<tr>
      <td>${r.matchNo}</td>
      <td>${r.date}</td>
      <td>${r.homeTeam}</td>
      <td>${r.score}</td>
      <td>${r.awayTeam}</td>
      <td>${r.venue}</td>
    </tr>`;
  });
}

function renderStandings(type) {
  const data = getData();
  const table = document.getElementById(`${type}-standings-table`);
  if (!table) return;
  table.innerHTML = "";

  let standings = Object.values(data[type].standings);
  standings.sort((a, b) => b.points - a.points || b.gd - a.gd);

  standings.forEach(s => {
    table.innerHTML += `<tr>
      <td>${s.team}</td>
      <td>${s.played}</td>
      <td>${s.won}</td>
      <td>${s.drawn}</td>
      <td>${s.lost}</td>
      <td>${s.gf}</td>
      <td>${s.ga}</td>
      <td>${s.gd}</td>
      <td>${s.points}</td>
    </tr>`;
  });
}

/******************************
  APPLICATIONS (Super Admin)
*******************************/
function renderApplications() {
  let data = getData();
  const table = document.getElementById("applications-table");
  if (!table) return;
  table.innerHTML = "";
  data.applications.forEach(app => {
    table.innerHTML += `<tr>
      <td>${app.name}</td>
      <td>${app.email}</td>
      <td>${app.phone}</td>
      <td>${app.address}</td>
      <td>${app.skill}</td>
      <td>${app.message || ""}</td>
      <td>${app.date}</td>
    </tr>`;
  });
}

function exportApplications() {
  let data = getData().applications;
  if (data.length === 0) {
    alert("No applications to export.");
    return;
  }
  let csv = "Name,Email,Phone,Address,Skill,Message,Date\n";
  data.forEach(app => {
    csv += `"${app.name}","${app.email}","${app.phone}","${app.address}","${app.skill}","${app.message}","${app.date}"\n`;
  });
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "applications.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function clearApplications() {
  if (confirm("Are you sure you want to clear all applications?")) {
    let data = getData();
    data.applications = [];
    saveData(data);
    renderApplications();
  }
}